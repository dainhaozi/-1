package com.example.loginpage

data class RefreshTokenRequest(
    val userName: String,
    val permToken: String
)