package com.example.loginpage

data class LoginRequest(
    val mobile: String,
    val password: String
)